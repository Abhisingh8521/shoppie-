import 'package:flutter/cupertino.dart';

extension Size on int {
  SizedBox get height => SizedBox(
        height: toDouble(),width: toDouble(),
      );
}
