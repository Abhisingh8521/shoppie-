

import 'package:flutter/material.dart';

class AppConstant {
  static String appMainName = 'Shoppie';
  static String appPoweredBy = 'Welcome to Shoppie';
  static String appVersion = '1.0.1';
  static String whatsAppNumber = '+918521616449';
  static const appMainColor = Color(0xfff1572cb);
  static const appScendoryColor =  Color(0xfff3195e6);
  static const appTextColor = Color(0xFFFBF5F4);
  static const appStatusBarColor = Color(0xFFFBF5F4);
}
