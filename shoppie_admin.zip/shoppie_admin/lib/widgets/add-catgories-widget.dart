import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../utils/constant.dart';

class AddCategoriesWidget {
  BuildContext context;

  AddCategoriesWidget({required this.context});

  Widget fieldView({
    required TextEditingController controller, required String text, required IconData icon,required TextInputType type,  bool? enabled,void Function()? onTap}) {
    return GestureDetector(
      onTap: onTap ?? (){},
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 5.0),
        width: Get.width,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: TextFormField(
            controller: controller,
            enabled: enabled ?? true,
            cursorColor: AppConstant.appScendoryColor,
            keyboardType: type,
            decoration: InputDecoration(
              hintText: text,
              prefixIcon: Icon(icon),
              contentPadding: EdgeInsets.only(top: 2.0, left: 8.0),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget checkBoxView(bool value, {required void Function(bool?)? onChanged}) =>
      CheckboxListTile(
        value: value,
        onChanged: onChanged,
        title: Text("Is Sale"),
      );

  Widget addButtonView(String title, {required void Function()? onPressed}) =>
      ElevatedButton(onPressed: onPressed, child: Text(title));
}
