import 'dart:io';
import 'package:admin_panel/models/categories-model.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import '../models/products-model.dart';
import '../utils/constant.dart';
import '../widgets/add-catgories-widget.dart';

class AddProductsScreen extends StatefulWidget {
  AddProductsScreen({Key? key}) : super(key: key);

  @override
  _AddProductsScreenState createState() => _AddProductsScreenState();
}

class _AddProductsScreenState extends State<AddProductsScreen> {
  late TextEditingController productNameCon;
  late TextEditingController categoryNameCon;
  late TextEditingController salePriceCon;
  late TextEditingController fullPriceCon;
  late TextEditingController deliveryTimeCon;
  late TextEditingController productDescriptionCon;
  bool isSale = false;
  File? _image;
  var categoryId = "";

  @override
  void initState() {
    super.initState();
    productNameCon = TextEditingController();
    categoryNameCon = TextEditingController();
    salePriceCon = TextEditingController();
    fullPriceCon = TextEditingController();
    deliveryTimeCon = TextEditingController();
    productDescriptionCon = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    var view = AddCategoriesWidget(context: context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppConstant.appScendoryColor,
        centerTitle: true,
        title: const Text(
          "Add Products",
          style: TextStyle(color: AppConstant.appTextColor),
        ),
      ),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 150,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Center(
                          child: _image == null
                              ? Text('No image selected.')
                              : Image.file(_image!, width: 400),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          final image = await ImagePicker()
                              .pickImage(source: ImageSource.gallery);
                          if (image != null) {
                            setState(() {
                              _image = File(image.path);
                            });
                          }
                        },
                        child: Text('Select image'),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: Get.height / 20),
              view.fieldView(
                controller: productNameCon,
                text: "Product Name",
                icon: Icons.category,
                type: TextInputType.text,
              ),
              SizedBox(height: 10),
              view.fieldView(
                controller: categoryNameCon,
                text: "choose Category Name",
                icon: Icons.category,
                type: TextInputType.text,
                enabled: false,
                onTap: () {
                  openBottomSheet(context);
                },
              ),
              SizedBox(height: 10),
              view.fieldView(
                controller: salePriceCon,
                text: "Sale Price",
                icon: Icons.monetization_on,
                type: TextInputType.number,
              ),
              SizedBox(height: 10),
              view.fieldView(
                controller: fullPriceCon,
                text: "Full Price",
                icon: Icons.monetization_on_outlined,
                type: TextInputType.number,
              ),
              SizedBox(height: 10),
              view.fieldView(
                controller: deliveryTimeCon,
                text: "Delivery Time",
                icon: Icons.access_time,
                type: TextInputType.text,
              ),
              SizedBox(height: 10),
              view.fieldView(
                controller: productDescriptionCon,
                text: "Product Description",
                icon: Icons.description,
                type: TextInputType.multiline,
              ),
              SizedBox(height: 10),
              CheckboxListTile(
                title: Text("On Sale"),
                value: isSale,
                onChanged: (bool? value) {
                  setState(() {
                    isSale = value ?? false;
                  });
                },
              ),
              SizedBox(height: Get.height / 20),
              Material(
                child: InkWell(
                  onTap: () async {
                    String productName = productNameCon.text.trim();
                    String categoryName = categoryNameCon.text.trim();
                    String salePrice = salePriceCon.text.trim();
                    String fullPrice = fullPriceCon.text.trim();
                    String deliveryTime = deliveryTimeCon.text.trim();
                    String productDescription =
                        productDescriptionCon.text.trim();

                    if (_image != null &&
                        productName.isNotEmpty &&
                        categoryName.isNotEmpty &&
                        fullPrice.isNotEmpty &&
                        deliveryTime.isNotEmpty &&
                        productDescription.isNotEmpty) {
                      try {
                        // Show loading indicator
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return Center(
                              child: CircularProgressIndicator(),
                            );
                          },
                          barrierDismissible: false,
                        );
                        final storageRef = FirebaseStorage.instance.ref().child(
                            'products_images/${DateTime.now().millisecondsSinceEpoch}');
                        final uploadTask = storageRef.putFile(_image!);
                        final snapshot =
                            await uploadTask.whenComplete(() => null);
                        final downloadUrl = await snapshot.ref.getDownloadURL();

                        final productId = FirebaseFirestore.instance
                            .collection('products')
                            .doc()
                            .id;


                        final newProduct = ProductModel(
                          productId: productId,
                          categoryId: categoryId,
                          productName: productName,
                          categoryName: categoryName,
                          salePrice: salePrice,
                          fullPrice: fullPrice,
                          productImages: [downloadUrl],
                          deliveryTime: deliveryTime,
                          isSale: isSale,
                          productDescription: productDescription,
                          createdAt: Timestamp.now(),
                          updatedAt: Timestamp.now(),
                        );

                        await FirebaseFirestore.instance
                            .collection('products')
                            .doc(productId)
                            .set(newProduct.toMap());

                        Navigator.pop(context);

                        Fluttertoast.showToast(
                          msg: "Product saved successfully!",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: Colors.blue,
                          textColor: Colors.white,
                        );

                        Navigator.pop(context);
                      } catch (e) {
                        Navigator.pop(context);

                        Fluttertoast.showToast(
                          msg: "Add Data Failed! $e",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: Colors.red,
                          textColor: Colors.white,
                        );
                      }
                    } else {
                      Fluttertoast.showToast(
                        msg: "Please fill all fields and select an image",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.green,
                        textColor: Colors.white,
                      );
                    }
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: AppConstant.appScendoryColor,
                    ),
                    child: const Center(
                      child: Text(
                        "Save",
                        style: TextStyle(color: AppConstant.appTextColor),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    productNameCon.dispose();
    categoryNameCon.dispose();
    salePriceCon.dispose();
    fullPriceCon.dispose();
    deliveryTimeCon.dispose();
    productDescriptionCon.dispose();
    super.dispose();
  }

  void openBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return StreamBuilder(
          stream:
              FirebaseFirestore.instance.collection('categories').snapshots(),
          builder: (context, snapshot) {
            var categoryList = snapshot.data?.docs
                .map((e) => CategoriesModel.fromMap(e.data()))
                .toList();
            return ListView.builder(
              itemCount: categoryList?.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text("Category No. ${index + 1}"),
                  subtitle: Text(
                    "${categoryList?[index].categoryName}",
                  ),
                  onTap: () {
                    categoryNameCon.text =
                        "${categoryList?[index].categoryName}";
                    categoryId = categoryList?[index].categoryId ?? "";
                    Navigator.pop(context);
                  },
                );
              },
            );
          },
        );
      },
    );
  }
}
