import 'package:admin_panel/screens/main-screen.dart';
import 'package:admin_panel/widgets/add-catgories-widget.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddCategoriesScreen extends StatefulWidget {
  AddCategoriesScreen({Key? key}) : super(key: key);

  @override
  _AddCategoriesScreenState createState() => _AddCategoriesScreenState();
}

class _AddCategoriesScreenState extends State<AddCategoriesScreen> {
  late TextEditingController categoriesCon;
  File? _image;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    categoriesCon = TextEditingController();
  }

  Future<void> _addCategoryToFirestore(
      String categoryId, String imageUrl, String categoryName) async {
    try {
      EasyLoading.show();
      await firestore.collection('categories').doc(categoryId).set({
        'categoryId': categoryId,
        'categoryImg': imageUrl,
        'categoryName': categoryName,
        'createdAt': Timestamp.now(),
        'updatedAt': Timestamp.now(),
      });
      Fluttertoast.showToast(
        msg: "Category added successfully!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.green,
        textColor: Colors.white,
      );

      Navigator.pop(context);
    } catch (e) {
      EasyLoading.dismiss();
      Fluttertoast.showToast(
        msg: "Failed to add category: $e",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    }
  }

  Future<String> _uploadImageToFirebaseStorage(
      File imageFile, String imageName) async {
    try {
      final Reference storageReference =
          FirebaseStorage.instance.ref().child('category_images/$imageName');
      final UploadTask uploadTask = storageReference.putFile(imageFile);
      await uploadTask.whenComplete(() => null);
      final String imageUrl = await storageReference.getDownloadURL();
      return imageUrl;
    } catch (e) {
      throw Exception("Failed to upload image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    var view = AddCategoriesWidget(context: context);
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Categories"),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 150,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Center(
                          child: _image == null
                              ? Text('No image selected.')
                              : Image.file(
                                  _image!,
                                  width: 400,
                                ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          final image = await ImagePicker()
                              .pickImage(source: ImageSource.gallery);
                          if (image != null) {
                            setState(() {
                              _image = File(image.path);
                            });
                          }
                        },
                        child: Text('Select image'),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              view.fieldView(
                controller: categoriesCon,
                text: "Add Categories Name",
                icon: Icons.category,
                type: TextInputType.text,
              ),
              SizedBox(height: 20),
              Material(
                child: InkWell(
                  onTap: () async {
                    if (_image != null && categoriesCon.text.isNotEmpty) {
                      final String categoryName = categoriesCon.text.trim();
                      final String categoryId =
                          firestore.collection('categories').doc().id;
                      final String imageName =
                          '$categoryId.jpg'; // Unique image name
                      final String imageUrl =
                          await _uploadImageToFirebaseStorage(
                              _image!, imageName);
                      await _addCategoryToFirestore(
                          categoryId, imageUrl, categoryName);
                    } else {
                      Fluttertoast.showToast(
                        msg: "Please select an image and fill all fields",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.red,
                        textColor: Colors.white,
                      );
                    }
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.blue,
                    ),
                    child: Center(
                      child: Text(
                        "Save",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    categoriesCon.dispose();
    super.dispose();
  }
}
