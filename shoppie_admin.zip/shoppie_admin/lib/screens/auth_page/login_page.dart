import 'package:admin_panel/screens/auth_page/sing_up.dart';
import 'package:admin_panel/widgets/add-catgories-widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:get/get.dart';

import '../main-screen.dart';


class SignInScreen extends StatefulWidget {
  const SignInScreen({Key? key}) : super(key: key);

  @override
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController userEmail = TextEditingController();
  TextEditingController userPassword = TextEditingController();

  void signInWithEmailAndPassword(String email, String password) async {
    try {
      EasyLoading.show(status: "Please wait");
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      EasyLoading.dismiss();
      Fluttertoast.showToast(
        msg: "Sign in successful!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => MainScreen()),
      );
    } catch (e) {
      EasyLoading.dismiss();
      Get.snackbar(
        "Sign in Fail",
        "Please Create An Account!",
        backgroundColor: Colors.black,
        colorText: Colors.white,
        duration: Duration(seconds: 2),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var view = AddCategoriesWidget(context: context);
    return KeyboardVisibilityBuilder(builder: (context, isKeyboardVisible) {
      return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const Text(
            "Sign In",
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(
                height: 100,
              ),
              view.fieldView(
                controller: userEmail,
                text: "Enter your email",
                icon: Icons.email,
                type: TextInputType.emailAddress,
              ),
              view.fieldView(
                controller: userPassword,
                text: "Enter your password",
                icon: Icons.lock,
                type: TextInputType.number,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 20,
              ),
              Material(
                child: Container(
                  width: MediaQuery.of(context).size.width / 2,
                  height: MediaQuery.of(context).size.height / 18,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: TextButton(
                    child: const Text(
                      "SIGN IN",
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      if (userEmail.text.isEmpty || userPassword.text.isEmpty) {
                        Fluttertoast.showToast(
                          msg: "Email and password cannot be empty",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                        );
                      } else {
                        signInWithEmailAndPassword(
                            userEmail.text, userPassword.text);
                      }
                    },
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     const Text(
              //       "Don't have an account? ",
              //       style: TextStyle(color: Colors.blue),
              //     ),
              //     GestureDetector(
              //       onTap: () => Navigator.push(
              //         context,
              //         MaterialPageRoute(builder: (context) => SingupScrrens()),
              //       ),
              //       child: const Text(
              //         "Sign Up",
              //         style: TextStyle(
              //             color: Colors.blue, fontWeight: FontWeight.bold),
              //       ),
              //     ),
              //   ],
              // )
            ],
          ),
        ),
      );
    });
  }
}
