// import 'package:admin_panel/screens/main-screen.dart';
// import 'package:flutter/material.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:get/get.dart';
//
// import '../../utils/constant.dart';
// import '../../widgets/add-catgories-widget.dart';
//
// class SingupScrrens extends StatefulWidget {
//   @override
//   _SingupScrrensState createState() => _SingupScrrensState();
// }
//
// class _SingupScrrensState extends State<SingupScrrens> {
//   final FirebaseAuth _auth = FirebaseAuth.instance;
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//
//   var nameController = TextEditingController();
//   var emailController = TextEditingController();
//   var passController = TextEditingController();
//
//   Future<void> _registerWithEmailAndPassword() async {
//     String name = nameController.text.trim();
//     String email = emailController.text.trim();
//     String password = passController.text.trim();
//
//     if (name.isEmpty || email.isEmpty || password.isEmpty) {
//       Fluttertoast.showToast(
//         msg: "Please fill all the fields",
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.BOTTOM,
//       );
//       return;
//     }
//
//     try {
//       UserCredential userCredential =
//           await _auth.createUserWithEmailAndPassword(
//         email: email,
//         password: password,
//       );
//
//       await _firestore
//           .collection('adminUsers')
//           .doc(userCredential.user!.uid)
//           .set({
//         'name': name,
//         'email': email,
//       });
//
//       Fluttertoast.showToast(
//         msg: "User registered successfully",
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.BOTTOM,
//       );
//       Get.offAll(()=>MainScreen());
//     } catch (e) {
//       print("Error registering user: $e");
//       Fluttertoast.showToast(
//         msg: "Error registering user: $e",
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.BOTTOM,
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     var view = AddCategoriesWidget(context: context);
//     return Scaffold(
//       appBar: AppBar(
//         iconTheme: IconThemeData(
//           color: AppConstant.appTextColor,
//         ),
//         backgroundColor: AppConstant.appMainColor,
//         title: Text(
//           "Register here",
//           style: TextStyle(color: AppConstant.appTextColor),
//         ),
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(10.0),
//           child: Column(
//             children: [
//               SizedBox(height: 90,),
//               view.fieldView(
//                   controller: nameController,
//                   text: "Name",
//                   icon: Icons.person,
//                   type: TextInputType.text),
//               view.fieldView(
//                   controller: emailController,
//                   text: "Email",
//                   icon: Icons.email,
//                   type: TextInputType.emailAddress),
//               view.fieldView(
//                   controller: passController,
//                   text: "Password",
//                   icon: Icons.lock,
//                   type: TextInputType.number),
//               ElevatedButton(
//                 onPressed: _registerWithEmailAndPassword,
//                 child: Text("Sign Up"),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
