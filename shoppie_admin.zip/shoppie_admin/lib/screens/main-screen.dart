import 'package:admin_panel/screens/Add-products.dart';
import 'package:admin_panel/utils/app-extetension/app-extension.dart';
import 'package:admin_panel/utils/constant.dart';
import 'package:admin_panel/widgets/drawer-widget.dart';
import 'package:flutter/material.dart';


import 'add-catgories.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppConstant.appMainColor,
        title: const Text("Admin Panel", style: TextStyle(color: Colors.white)),
      ),
      drawer: DrawerWidget(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'DashBoard',
              style: TextStyle(
                fontSize: 35,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                letterSpacing: 0.1,
              ),
            ),
            10.height,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => AddCategoriesScreen(),));

                  },
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Container(
                      width: 150,
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.blue,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.category, color: Colors.cyanAccent),
                          Text('Add Category',
                              style: TextStyle(
                                  fontSize: 17, fontStyle: FontStyle.italic)),
                        ],
                      ),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => AddProductsScreen(),));
                    // Add your onTap logic here
                  },
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Container(
                      width: 150,
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.cyan,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.girl ,color: Colors.grey,),
                          Text('Add Products',
                              style: TextStyle(
                                  fontSize: 17, fontStyle: FontStyle.italic)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //   children: [
            //     InkWell(
            //       onTap: () {
            //         // Add your onTap logic here
            //       },
            //       child: Card(
            //         elevation: 5,
            //         shape: RoundedRectangleBorder(
            //           borderRadius: BorderRadius.circular(15),
            //         ),
            //         child: Container(
            //           width: 150,
            //           height: 100,
            //           decoration: BoxDecoration(
            //             borderRadius: BorderRadius.circular(15),
            //             color: Colors.green,
            //           ),
            //           child: Column(
            //             mainAxisAlignment: MainAxisAlignment.center,
            //             children: [
            //               Image.asset('assets/profile.png', width: 34, height: 27),
            //               Text('Profile', style: TextStyle(fontSize: 17, fontStyle: FontStyle.italic)),
            //             ],
            //           ),
            //         ),
            //       ),
            //     ),
            //     InkWell(
            //       onTap: () {
            //         // Add your onTap logic here
            //       },
            //       child: Card(
            //         elevation: 5,
            //         shape: RoundedRectangleBorder(
            //           borderRadius: BorderRadius.circular(15),
            //         ),
            //         child: Container(
            //           width: 150,
            //           height: 100,
            //           decoration: BoxDecoration(
            //             borderRadius: BorderRadius.circular(15),
            //             color: Colors.green,
            //           ),
            //           child: Column(
            //             mainAxisAlignment: MainAxisAlignment.center,
            //             children: [
            //               Image.asset('assets/addusers.png', width: 34, height: 27),
            //               Text('Create New User', style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic)),
            //             ],
            //           ),
            //         ),
            //       ),
            //     ),
            //   ],
            // ),
            SizedBox(height: 20),
            // InkWell(
            //   onTap: () {
            //     // Add your onTap logic here
            //   },
            //   child: Card(
            //     elevation: 5,
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(15),
            //     ),
            //     child: Container(
            //       width: 150,
            //       height: 100,
            //       decoration: BoxDecoration(
            //         borderRadius: BorderRadius.circular(15),
            //         color: Colors.green,
            //       ),
            //       child: Column(
            //         mainAxisAlignment: MainAxisAlignment.center,
            //         children: [
            //           Image.asset('assets/dispatch.png', width: 34, height: 27),
            //           Text('Add Menu', style: TextStyle(fontSize: 17, color: Colors.yellow, fontStyle: FontStyle.italic)),
            //         ],
            //       ),
            //     ),
            //   ),
            // ),
            SizedBox(height: 20),
            // InkWell(
            //   onTap: () {
            //     // Add your onTap logic here
            //   },
            //   child: Card(
            //     elevation: 5,
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(15),
            //     ),
            //     child: Container(
            //       width: 150,
            //       height: 100,
            //       decoration: BoxDecoration(
            //         borderRadius: BorderRadius.circular(15),
            //         color: Colors.green,
            //       ),
            //       child: Column(
            //         mainAxisAlignment: MainAxisAlignment.center,
            //         children: [
            //           Image.asset('assets/logout.png', width: 34, height: 27),
            //           Text('Logout', style: TextStyle(fontSize: 17, color: Colors.red, fontStyle: FontStyle.italic)),
            //         ],
            //       ),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
