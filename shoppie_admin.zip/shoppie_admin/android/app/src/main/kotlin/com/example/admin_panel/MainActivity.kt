package com.example.admin_panel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
